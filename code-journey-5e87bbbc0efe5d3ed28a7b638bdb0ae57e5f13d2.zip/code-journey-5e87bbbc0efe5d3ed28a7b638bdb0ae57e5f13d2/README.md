# code journey 
Hi,I am Preeti Singh
This repository contains my coding practice and projects.

## Skills
- HTML5
- Basic css
- JavaScript(fundamentals)
- C Programming
- Data Structures(basics)
  
 ## Currently Improving
  - Advanced JavaScript
  - CSS Styling and Responsive Design
  - Problem Solving Skills
  - Building Real World Projects
  
 ## Projects
  
 ### Traffic Management System
  A System designed to manage and optimize traffic flow using structured logic and system design concepts.
  
  ### AI Resume and Job Description Matcher
  An intelligent system with job descriptions using AI concepts to improve hiring efficiency
  
  ## Career Goal
  To become a skilled Full Stack Developer and build impactful AI-powered applications.
